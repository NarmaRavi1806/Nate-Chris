package com.cg.demo.MVCinSpringBoot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MvCinSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(MvCinSpringBootApplication.class, args);
	}
}
