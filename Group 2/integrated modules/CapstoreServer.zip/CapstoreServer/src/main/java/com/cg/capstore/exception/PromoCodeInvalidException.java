package com.cg.capstore.exception;

public class PromoCodeInvalidException extends Exception {

	public PromoCodeInvalidException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public PromoCodeInvalidException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
