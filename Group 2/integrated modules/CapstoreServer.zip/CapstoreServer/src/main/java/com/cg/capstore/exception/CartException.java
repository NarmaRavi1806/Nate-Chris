package com.cg.capstore.exception;

public class CartException extends Exception {

	public CartException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CartException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
