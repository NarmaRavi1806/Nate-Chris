package com.cg.capstore.exception;

public class GeneratingCouponsException extends Exception {

	public GeneratingCouponsException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public GeneratingCouponsException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
